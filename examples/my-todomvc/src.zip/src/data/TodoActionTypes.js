const ActionTypes = {
  ADD_TODO: 'ADD_TODO',
};

export default ActionTypes;